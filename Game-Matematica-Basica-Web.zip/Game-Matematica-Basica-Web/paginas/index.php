<?php
include "chamarformatacao.php";
 ?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>
    <title>Tela Inicial</title>
    <meta charset="utf-8">
  </head>
  <body class="bg-dark">
    <style>
      .medio {
                width: 18.8%;
              }
    </style>
    <div class="p-4 m-1">

    </div>
    <div class="container bg-warning">
      <div class="row">
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/ab/Logo_TV_2015.png" alt="" width=60 height=40>
          <div class="col-sm-11 pt-5" align="center">
            <div class="p-2 m-4">

            </div>
            <a
              href="jogar.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio"
              id="btnJogar">
              Jogar
            </a>
            <br>
            <br>
            <a
              href="comojogar.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio"
              id="btnInstru">
              Como Jogar?
            </a>
            <br>
            <br>
            <a
              href="ranking.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio"
              id="btnRanking">
              Ranking
            </a>
            <div class="p-5 m-5">
              <div class="p-1 m-1">

              </div>
            </div>
        </div>
      </div>
    </div>
    <div class="p-4 m-1">

    </div>
  </body>
</html>
