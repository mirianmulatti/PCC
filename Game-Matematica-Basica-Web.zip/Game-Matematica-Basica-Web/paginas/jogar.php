<?php
include "chamarformatacao.php";
 ?>

<!DOCTYPE html>
<html lang="pt-br" dir="ltr">
  <head>

    <title>Tela Jogo</title>

  </head>
  <body class="bg-dark">
    <style>
      .medio {
                width: 22.8%;
              }
    </style>
    <div class="p-2 m-1">

    </div>
    <div class="container bg-warning">
      <div class="row">
        <img src="https://upload.wikimedia.org/wikipedia/commons/a/ab/Logo_TV_2015.png" alt="" width=60 height=40>
          <div class="col-sm-11 pt-5" align="center">

            <div class="p-2 m-4">

            </div>
            <a
              href="cadastroAluno.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio">
              Cadastro Aluno
            </a>
            <br>
            <br>
            <a
              href="cadastroProfessor.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio">
              Cadastro Professor
            </a>
            <br>
            <br>
            <a
              href="cadastroEscola.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio">
              Cadastro Escola
            </a>
            <br>
            <br>
            <a
              href="login.php"
              class="btn btn-danger pl-5 pr-5 pt-3 pb-3 medio">
              Login
            </a>
            <br>
            <div class="p-5 m-5">

            </div>
        </div>
      </div>
    </div>
  </body>
</html>
